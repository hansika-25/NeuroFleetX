// src/routes/tickets.js
const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketController');
const auth = require('../middlewares/auth');

// get one ticket
router.get('/:ticketId', auth.verifyToken, ticketController.getById);

// list user tickets
router.get('/user/:userId', auth.verifyToken, ticketController.listByUser);

module.exports = router;
